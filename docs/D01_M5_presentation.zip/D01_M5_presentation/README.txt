Battery Copilot · Team D01 · M5 presentation

Open present.html in Chrome or Edge (needs an internet connection for the font and charts).
Arrow keys or click to move between slides. Press F for full screen.
Slides 5, 6 and 9 embed the live app: click inside them to use it (press Play on slide 6).

If the live slides stay blank when opened straight from the folder, serve it instead:
  python3 -m http.server 8600   (run inside this folder)
  then open http://localhost:8600/present.html
